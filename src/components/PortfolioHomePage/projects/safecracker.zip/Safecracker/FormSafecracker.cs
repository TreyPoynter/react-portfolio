﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Safecracker
{
    public partial class FormSafecracker : Form
    {
        // Class Level Variables
        internal UserAccount userAccount;
        SoundPlayer correctSound, wrongSound;
        const int MIN_VALUE = 1, MAX_VALUE = 9;
        static string secretCode = String.Empty, enteredCombo;
        static int numOfDigits, digitsEntered = 0;
        
        // Class Level GUI Arrays
        static Label[] digitLabels = new Label[4];
        static Button[] digitButtons = new Button[9];

        public FormSafecracker()
        {
            InitializeComponent();
        }

        #region Event Methods
        private void FormSafecracker_Load(object sender, EventArgs e)
        {
            // Label Controls
            digitLabels[0] = lblCombo1;
            digitLabels[1] = lblCombo2;
            digitLabels[2] = lblCombo3;
            digitLabels[3] = lblCombo4;

            // Button Controls
            digitButtons[0] = btn1;
            digitButtons[1] = btn2;
            digitButtons[2] = btn3;
            digitButtons[3] = btn4;
            digitButtons[4] = btn5;
            digitButtons[5] = btn6;
            digitButtons[6] = btn7;
            digitButtons[7] = btn8;
            digitButtons[8] = btn9;

            // Assign Sounds
            correctSound = new SoundPlayer(Application.StartupPath + "\\SoTwinning.wav");
            wrongSound = new SoundPlayer(Application.StartupPath + "\\dead-body-reported.wav");

            // Get default selections
            rdoTwoDigits.Checked = true;
            pnlSafe.Enabled = false;
            rtbResults.ReadOnly = true;
        }
        private void btnStartStop_Click(object sender, EventArgs e)
        {
            if (btnStartStop.Text == "Start Game")
            {
                StartGame();
            }
            else if (btnStartStop.Text == "Stop Game")
            {
                StopGame();
            }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btnCombo_Click(object sender, EventArgs e)
        {
            Button buttonClicked;
            string buttonName, numberSelected;

            buttonClicked = (Button)sender;
            buttonName = buttonClicked.Name;

            numberSelected = buttonClicked.Text;
            buttonClicked.Enabled = false;

            enteredCombo = numberSelected;

            if (digitsEntered < 1)
            {
                foreach (Label label in digitLabels)
                {
                    label.Text = String.Empty;
                }
            }
            
            digitLabels[digitsEntered].Text += enteredCombo;
            digitsEntered++;

            if (digitsEntered == numOfDigits)
            {
                CompleteAttempt();
            }
        }
        #endregion

        void StartGame()
        {
            for (int index = 0; index < digitLabels.Length; index++)
            {
                digitLabels[index].Text = String.Empty;
            }
            userAccount.Attempts = 0;
            rtbResults.Clear();
            ReenableButtons();
            digitsEntered = 0;
            secretCode = String.Empty;
            numOfDigits = rdoTwoDigits.Checked ? 2 : rdoThreeDigits.Checked ? 3 : 4;
            GenerateSecretCode();
            btnStartStop.Text = "Stop Game";
            ShowAndHideLabels();
            grpOptions.Enabled = false;
            btnExit.Enabled = false;
            pnlSafe.Enabled = true;
            
            Console.WriteLine(secretCode);
        }

        void StopGame()
        {
            grpOptions.Enabled = true;
            btnStartStop.Text = "Start Game";
            btnExit.Enabled = true;
            pnlSafe.Enabled = false;
        }

        static void ShowAndHideLabels()
        {
            for (int index = 0; index < numOfDigits; index++)
            {
                digitLabels[index].Visible = true;
            }

            for (int index = numOfDigits; index < digitLabels.Length ; index++)
            {
                digitLabels[index].Visible = false;
            }
        }

        static void ReenableButtons()
        {
            foreach (Button button in digitButtons)
            {
                button.Enabled = true;
            }
        }

        void CompleteAttempt()
        {
            userAccount.Attempts++;
            enteredCombo = String.Empty;
            for (int index = 0; index < numOfDigits; index++)
            {
                enteredCombo += digitLabels[index].Text;
            }
            CompareCombinations();
            ReenableButtons();
            digitsEntered = 0;
        }

        static void GenerateSecretCode()
        {
            int diget;
            Random rand = new Random();

            for (int currentDiget = 1; currentDiget <= numOfDigits; currentDiget++)
            {
                do
                {
                    diget = rand.Next(MIN_VALUE, MAX_VALUE + 1);
                } while (secretCode.Contains(diget.ToString()));

                secretCode += diget.ToString();
            }
        }
        void CompareCombinations()
        {
            int numRight = 0, positionRight = 0;

            if (enteredCombo == secretCode)
            {
                correctSound.Play();
                StopGame();
                rtbResults.Text += $"You win after {userAccount.Attempts} attempts";
            }
            else
            {
                wrongSound.Play();
                for (int index = 0; index < secretCode.Length; index++)
                {
                    if (enteredCombo[index] != secretCode[index])
                    {
                        if (enteredCombo.Contains(secretCode[index]))
                        {
                            ++numRight;
                        }
                    }
                    else
                    {
                        ++positionRight;
                    }
                }
                rtbResults.AppendText($"{userAccount.Attempts}. You entered {enteredCombo}\n" +
                                  $"{numRight} digits correct\n" +
                                  $"{positionRight} in correct position\n\n");
            }
            
            rtbResults.ScrollToCaret();
        }
    }
}