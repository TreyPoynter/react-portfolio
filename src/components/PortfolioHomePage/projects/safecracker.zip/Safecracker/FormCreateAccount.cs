﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Safecracker
{
    public partial class FormCreateAccount : Form
    {
        UserAccount userAccount;
        private const string FILE_NAME = "UserAccountsInfo.txt";
        const int MIN_SIZE = 3, MAX_SIZE = 9;
        List<string> accountNames = new List<string>(); // holds existing account names

        public FormCreateAccount()
        {
            InitializeComponent();
        }

        #region Event Methods
        private void FormCreateAccount_Load(object sender, EventArgs e)
        {
            StreamReader reader = null;
            bool ioError = false;
            string fileRecord = String.Empty;
            string[] fields = new string[5]; // an array to hold each field in a record

            try
            {
                reader = new StreamReader(FILE_NAME);
                while (!reader.EndOfStream)
                {
                    fileRecord = reader.ReadLine();
                    fields = fileRecord.Split(',');
                    accountNames.Add(fields[0]);
                }
            }
            catch (FileNotFoundException fileExc)
            {
                // first account created what why is it not here >:((
                Console.WriteLine(fileExc.Message);
            }
            catch (Exception exc)
            {
                MessageBox.Show(String.Format($"Error reading file {FILE_NAME} - error {exc.Message}"));
                ioError = true;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                if (ioError)
                    Environment.Exit(0);
            }
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            bool isValidInfo;

            isValidInfo = ValidateAccountName();

            if (isValidInfo)
            {
                isValidInfo = ValidatePassword();
            }

            if (isValidInfo)
            {
                CreateUserAccount();
                SaveUserAccount();
                PlayGame();
            }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void lnkLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormLogIn formLogIn = new FormLogIn();
            formLogIn.Show();
            this.Hide();
        }
        #endregion

        private bool ValidateAccountName()
        {
            bool validData = true;

            txtUsername.Text = txtUsername.Text.Trim();
            if (txtUsername.Text.Length < MIN_SIZE || txtUsername.Text.Length > MAX_SIZE)
            {
                lblErrorUsername.Visible = true;
                validData = false;
            }
            else
            {
                if (!ValidateUniqueAccountName())
                {
                    //lblErrorUsername.Text = "Username already exists";
                    lblErrorUsername.Visible = true;
                    validData = false;
                }
                else
                {
                    lblErrorUsername.Visible = false;
                }
            }

            return validData;
        }
        private bool ValidateUniqueAccountName()
        {
            bool isUnique = true;

            return isUnique = !accountNames.Exists(item => item == txtUsername.Text);
        }

        private bool ValidatePassword()
        {
            bool validData = true;
            string userPass = txtPassword.Text;
            var regexItem = new Regex("^[a-zA-Z0-9 ]*$");

            // check if password has 1 uppercase, 1 special char, and is in the parameters\
            if (userPass.Length < MIN_SIZE || userPass.Length > MAX_SIZE)
            {
                MessageBox.Show($"Password has to be between {MIN_SIZE} - {MAX_SIZE}");
                validData = false;
                lblErrorPassword.Visible = true;
            }
            if (validData && (regexItem.IsMatch(userPass) || !userPass.Any(char.IsUpper)))
            {
                MessageBox.Show($"Password has to contain 1 special character and 1 upper");
                validData = false;
                lblErrorPassword.Visible = true;

            }

            return validData;

        }
        private void CreateUserAccount()
        {
            userAccount = new UserAccount() { UserName = txtUsername.Text, Password = txtPassword.Text };
        }
        private void SaveUserAccount()
        {
            StreamWriter outPutFile = null;
            string record;
            bool ioError = false;

            try
            {
                outPutFile = new StreamWriter(FILE_NAME, true);

                record = userAccount.UserName + ", "
                    + userAccount.Password + ", "
                    + userAccount.ComboSize + ", "
                    + userAccount.GameplayTime + ", "
                    + userAccount.Attempts;
                outPutFile.WriteLine(record);
            }
            catch (Exception exc)
            {
                MessageBox.Show(String.Format($"Error writing file {FILE_NAME} - error {exc.Message}"));
            }
            finally
            {
                if (outPutFile != null)
                    outPutFile.Close();
                if (ioError)
                    Environment.Exit(0);
            }
        }
        void UpdateAccountInfo()
        {
            string[] records = File.ReadAllLines(FILE_NAME);
            for (int index = 0; index < records.Length; index++)
            {
                string[] fields = records[index].Split(", ".ToCharArray());
                if (fields[0] == userAccount.UserName)
                {
                    records[index] = userAccount.UserName + ", "
                    + userAccount.Password + ", "
                    + userAccount.ComboSize + ", "
                    + userAccount.GameplayTime + ", "
                    + userAccount.Attempts;
                }
            }
            File.WriteAllLines(FILE_NAME, records);
        }
        private void PlayGame()
        {
            FormSafecracker formSafecracker = new FormSafecracker();
            formSafecracker.userAccount = this.userAccount;
            formSafecracker.Show();
            this.Hide();
        }

        
    }
}