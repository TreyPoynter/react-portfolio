﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safecracker
{
    class UserAccount
    {
        public string UserName { get; set; }
        public string Password  { get; set; }
        public int ComboSize { get; set; }
        public TimeSpan GameplayTime { get; set; }
        public int Attempts { get; set; }

    }
}
