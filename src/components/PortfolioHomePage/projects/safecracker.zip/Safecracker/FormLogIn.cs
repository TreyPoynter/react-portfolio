﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Safecracker
{
    public partial class FormLogIn : Form
    {
        const int MIN_SIZE = 3, MAX_SIZE = 9;
        private const string FILE_NAME = "UserAccountsInfo.txt";
        List<string> users = new List<string>();
        List<string> passwords = new List<string>();

        public FormLogIn()
        {
            InitializeComponent();
        }

        #region Event Methods
        private void FormLogIn_Load(object sender, EventArgs e)
        {
            StreamReader reader = null;
            bool ioError = false;
            string fileRecord = String.Empty;
            string[] fields = new string[4];
            
            try
            {
                reader = new StreamReader(FILE_NAME);
                while (!reader.EndOfStream)
                {
                    fileRecord = reader.ReadLine();
                    fields = fileRecord.Split(", ".ToCharArray());
                    users.Add(fields[0]);
                }
            }
            catch (FileNotFoundException exc)
            {
                Console.WriteLine(exc.Message);
            }
            catch (Exception exc)
            {
                MessageBox.Show(String.Format($"Error writing file {FILE_NAME} - error {exc.Message}"));
                ioError = true;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                if (ioError)
                    Environment.Exit(0);
            }
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (users.Contains(txtUsername.Text) && passwords.Contains(txtPassword.Text) && 
                Array.IndexOf(users.ToArray(), txtUsername.Text) == Array.IndexOf(passwords.ToArray(), txtPassword.Text)) 
            {
                FormSafecracker formSafecracker = new FormSafecracker();
                formSafecracker.Show();
                Hide();

                // transfer data from the txt file to the form because I have no clue how to do that >:((
                //formSafecracker.userAccount = UserAccount();
            }
            else if (users.Contains(txtUsername.Text) && !passwords.Contains(txtPassword.Text))
            {
                MessageBox.Show("Invalid password for account");
            }
            else
            {
                MessageBox.Show("Account doesn't exist");
            }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void lnkCreateAccount_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormCreateAccount formCreateAccount = new FormCreateAccount();
            formCreateAccount.Show();
            Close();
        }
        #endregion

        void LaodAccounts()
        {
            UserAccount userAccount;
            StreamReader reader = null;
            bool ioError = false;
            string fileRecord = String.Empty;
            string[] fields = new string[5]; // this is here to segment each part of a user account with the ", "

            try
            {
                reader = new StreamReader(FILE_NAME);
                while (!reader.EndOfStream)
                {
                    fileRecord = reader.ReadLine();
                    fields = fileRecord.Split(", ".ToCharArray());
                    userAccount = new UserAccount();
                    userAccount.UserName = fields[0];
                    userAccount.Password = fields[1];
                    userAccount.GameplayTime = TimeSpan.Parse(fields[2]);
                    userAccount.ComboSize = int.Parse(fields[3]);
                    userAccount.Attempts = int.Parse(fields[4]);

                    
                }
            }
            catch (Exception)
            {

            }
        }
    }
}