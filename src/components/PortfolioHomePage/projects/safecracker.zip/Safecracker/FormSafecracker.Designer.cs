﻿
namespace Safecracker
{
    partial class FormSafecracker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpOptions = new System.Windows.Forms.GroupBox();
            this.rdoFourDigits = new System.Windows.Forms.RadioButton();
            this.rdoThreeDigits = new System.Windows.Forms.RadioButton();
            this.rdoTwoDigits = new System.Windows.Forms.RadioButton();
            this.grpResults = new System.Windows.Forms.GroupBox();
            this.rtbResults = new System.Windows.Forms.RichTextBox();
            this.btnStartStop = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.pnlSafe = new System.Windows.Forms.Panel();
            this.lblCombo4 = new System.Windows.Forms.Label();
            this.lblCombo3 = new System.Windows.Forms.Label();
            this.lblCombo2 = new System.Windows.Forms.Label();
            this.lblCombo1 = new System.Windows.Forms.Label();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.picSafe = new System.Windows.Forms.PictureBox();
            this.grpOptions.SuspendLayout();
            this.grpResults.SuspendLayout();
            this.pnlSafe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSafe)).BeginInit();
            this.SuspendLayout();
            // 
            // grpOptions
            // 
            this.grpOptions.Controls.Add(this.rdoFourDigits);
            this.grpOptions.Controls.Add(this.rdoThreeDigits);
            this.grpOptions.Controls.Add(this.rdoTwoDigits);
            this.grpOptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpOptions.Location = new System.Drawing.Point(432, 5);
            this.grpOptions.Name = "grpOptions";
            this.grpOptions.Size = new System.Drawing.Size(356, 150);
            this.grpOptions.TabIndex = 2;
            this.grpOptions.TabStop = false;
            this.grpOptions.Text = "Options";
            // 
            // rdoFourDigits
            // 
            this.rdoFourDigits.AutoSize = true;
            this.rdoFourDigits.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rdoFourDigits.Location = new System.Drawing.Point(6, 94);
            this.rdoFourDigits.Name = "rdoFourDigits";
            this.rdoFourDigits.Size = new System.Drawing.Size(189, 24);
            this.rdoFourDigits.TabIndex = 2;
            this.rdoFourDigits.TabStop = true;
            this.rdoFourDigits.Text = "4 Digits in Combination";
            this.rdoFourDigits.UseVisualStyleBackColor = true;
            // 
            // rdoThreeDigits
            // 
            this.rdoThreeDigits.AutoSize = true;
            this.rdoThreeDigits.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rdoThreeDigits.Location = new System.Drawing.Point(6, 61);
            this.rdoThreeDigits.Name = "rdoThreeDigits";
            this.rdoThreeDigits.Size = new System.Drawing.Size(189, 24);
            this.rdoThreeDigits.TabIndex = 1;
            this.rdoThreeDigits.TabStop = true;
            this.rdoThreeDigits.Text = "3 Digits in Combination";
            this.rdoThreeDigits.UseVisualStyleBackColor = true;
            // 
            // rdoTwoDigits
            // 
            this.rdoTwoDigits.AutoSize = true;
            this.rdoTwoDigits.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rdoTwoDigits.Location = new System.Drawing.Point(6, 28);
            this.rdoTwoDigits.Name = "rdoTwoDigits";
            this.rdoTwoDigits.Size = new System.Drawing.Size(189, 24);
            this.rdoTwoDigits.TabIndex = 0;
            this.rdoTwoDigits.TabStop = true;
            this.rdoTwoDigits.Text = "2 Digits in Combination";
            this.rdoTwoDigits.UseVisualStyleBackColor = true;
            // 
            // grpResults
            // 
            this.grpResults.Controls.Add(this.rtbResults);
            this.grpResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpResults.Location = new System.Drawing.Point(432, 240);
            this.grpResults.Name = "grpResults";
            this.grpResults.Size = new System.Drawing.Size(356, 262);
            this.grpResults.TabIndex = 3;
            this.grpResults.TabStop = false;
            this.grpResults.Text = "Results";
            // 
            // rtbResults
            // 
            this.rtbResults.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.rtbResults.Location = new System.Drawing.Point(6, 19);
            this.rtbResults.Name = "rtbResults";
            this.rtbResults.Size = new System.Drawing.Size(344, 237);
            this.rtbResults.TabIndex = 0;
            this.rtbResults.Text = "";
            // 
            // btnStartStop
            // 
            this.btnStartStop.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStartStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartStop.Location = new System.Drawing.Point(540, 161);
            this.btnStartStop.Name = "btnStartStop";
            this.btnStartStop.Size = new System.Drawing.Size(151, 33);
            this.btnStartStop.TabIndex = 4;
            this.btnStartStop.Text = "Start Game";
            this.btnStartStop.UseVisualStyleBackColor = true;
            this.btnStartStop.Click += new System.EventHandler(this.btnStartStop_Click);
            // 
            // btnExit
            // 
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(540, 198);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(151, 33);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pnlSafe
            // 
            this.pnlSafe.BackColor = System.Drawing.Color.Transparent;
            this.pnlSafe.BackgroundImage = global::Safecracker.Properties.Resources.coconut;
            this.pnlSafe.Controls.Add(this.lblCombo4);
            this.pnlSafe.Controls.Add(this.lblCombo3);
            this.pnlSafe.Controls.Add(this.lblCombo2);
            this.pnlSafe.Controls.Add(this.lblCombo1);
            this.pnlSafe.Controls.Add(this.btn9);
            this.pnlSafe.Controls.Add(this.btn8);
            this.pnlSafe.Controls.Add(this.btn7);
            this.pnlSafe.Controls.Add(this.btn6);
            this.pnlSafe.Controls.Add(this.btn5);
            this.pnlSafe.Controls.Add(this.btn4);
            this.pnlSafe.Controls.Add(this.btn3);
            this.pnlSafe.Controls.Add(this.btn2);
            this.pnlSafe.Controls.Add(this.btn1);
            this.pnlSafe.Location = new System.Drawing.Point(103, 189);
            this.pnlSafe.Name = "pnlSafe";
            this.pnlSafe.Size = new System.Drawing.Size(248, 261);
            this.pnlSafe.TabIndex = 1;
            // 
            // lblCombo4
            // 
            this.lblCombo4.AutoSize = true;
            this.lblCombo4.BackColor = System.Drawing.Color.DimGray;
            this.lblCombo4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCombo4.Location = new System.Drawing.Point(176, 17);
            this.lblCombo4.Name = "lblCombo4";
            this.lblCombo4.Size = new System.Drawing.Size(29, 31);
            this.lblCombo4.TabIndex = 13;
            this.lblCombo4.Text = "0";
            // 
            // lblCombo3
            // 
            this.lblCombo3.AutoSize = true;
            this.lblCombo3.BackColor = System.Drawing.Color.DimGray;
            this.lblCombo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCombo3.Location = new System.Drawing.Point(132, 17);
            this.lblCombo3.Name = "lblCombo3";
            this.lblCombo3.Size = new System.Drawing.Size(29, 31);
            this.lblCombo3.TabIndex = 12;
            this.lblCombo3.Text = "0";
            // 
            // lblCombo2
            // 
            this.lblCombo2.AutoSize = true;
            this.lblCombo2.BackColor = System.Drawing.Color.DimGray;
            this.lblCombo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCombo2.Location = new System.Drawing.Point(88, 17);
            this.lblCombo2.Name = "lblCombo2";
            this.lblCombo2.Size = new System.Drawing.Size(29, 31);
            this.lblCombo2.TabIndex = 11;
            this.lblCombo2.Text = "0";
            // 
            // lblCombo1
            // 
            this.lblCombo1.AutoSize = true;
            this.lblCombo1.BackColor = System.Drawing.Color.DimGray;
            this.lblCombo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCombo1.Location = new System.Drawing.Point(44, 17);
            this.lblCombo1.Name = "lblCombo1";
            this.lblCombo1.Size = new System.Drawing.Size(29, 31);
            this.lblCombo1.TabIndex = 10;
            this.lblCombo1.Text = "0";
            // 
            // btn9
            // 
            this.btn9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.Location = new System.Drawing.Point(157, 192);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(48, 55);
            this.btn9.TabIndex = 9;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btnCombo_Click);
            // 
            // btn8
            // 
            this.btn8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.Location = new System.Drawing.Point(103, 192);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(48, 55);
            this.btn8.TabIndex = 8;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btnCombo_Click);
            // 
            // btn7
            // 
            this.btn7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.Location = new System.Drawing.Point(49, 192);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(48, 55);
            this.btn7.TabIndex = 7;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btnCombo_Click);
            // 
            // btn6
            // 
            this.btn6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.Location = new System.Drawing.Point(157, 131);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(48, 55);
            this.btn6.TabIndex = 6;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btnCombo_Click);
            // 
            // btn5
            // 
            this.btn5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.Location = new System.Drawing.Point(103, 131);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(48, 55);
            this.btn5.TabIndex = 5;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btnCombo_Click);
            // 
            // btn4
            // 
            this.btn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.Location = new System.Drawing.Point(49, 131);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(48, 55);
            this.btn4.TabIndex = 4;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btnCombo_Click);
            // 
            // btn3
            // 
            this.btn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.Location = new System.Drawing.Point(157, 70);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(48, 55);
            this.btn3.TabIndex = 3;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btnCombo_Click);
            // 
            // btn2
            // 
            this.btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.Location = new System.Drawing.Point(103, 70);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(48, 55);
            this.btn2.TabIndex = 2;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btnCombo_Click);
            // 
            // btn1
            // 
            this.btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.Location = new System.Drawing.Point(49, 70);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(48, 55);
            this.btn1.TabIndex = 1;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btnCombo_Click);
            // 
            // picSafe
            // 
            this.picSafe.Image = global::Safecracker.Properties.Resources.thebankbuttheb1;
            this.picSafe.Location = new System.Drawing.Point(12, 5);
            this.picSafe.Name = "picSafe";
            this.picSafe.Size = new System.Drawing.Size(414, 497);
            this.picSafe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSafe.TabIndex = 0;
            this.picSafe.TabStop = false;
            // 
            // FormSafecracker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 514);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnStartStop);
            this.Controls.Add(this.grpResults);
            this.Controls.Add(this.grpOptions);
            this.Controls.Add(this.pnlSafe);
            this.Controls.Add(this.picSafe);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormSafecracker";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Safecracker";
            this.Load += new System.EventHandler(this.FormSafecracker_Load);
            this.grpOptions.ResumeLayout(false);
            this.grpOptions.PerformLayout();
            this.grpResults.ResumeLayout(false);
            this.pnlSafe.ResumeLayout(false);
            this.pnlSafe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSafe)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picSafe;
        private System.Windows.Forms.Panel pnlSafe;
        private System.Windows.Forms.GroupBox grpOptions;
        private System.Windows.Forms.RadioButton rdoFourDigits;
        private System.Windows.Forms.RadioButton rdoThreeDigits;
        private System.Windows.Forms.RadioButton rdoTwoDigits;
        private System.Windows.Forms.GroupBox grpResults;
        private System.Windows.Forms.RichTextBox rtbResults;
        private System.Windows.Forms.Button btnStartStop;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblCombo4;
        private System.Windows.Forms.Label lblCombo3;
        private System.Windows.Forms.Label lblCombo2;
        private System.Windows.Forms.Label lblCombo1;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn1;
    }
}

