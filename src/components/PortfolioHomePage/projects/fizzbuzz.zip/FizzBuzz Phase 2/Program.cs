﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzz
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "FizzBuzz";

            for (int count = 1; count <= 100; count++)
                Console.WriteLine(count % 3 == 0 && count % 5 == 0 ? "FizzBuzz" : count % 3 == 0 ? "Fizz" : count % 5 == 0 ? "Buzz" : count.ToString());

            Console.ReadLine();
        }
    }
}
